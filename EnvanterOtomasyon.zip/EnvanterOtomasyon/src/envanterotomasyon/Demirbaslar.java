/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package envanterotomasyon;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Java3
 */
@Entity
@Table(name = "demirbaslar")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Demirbaslar.findAll", query = "SELECT d FROM Demirbaslar d"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasId", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasId = :demirbasId"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasUrunId", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasUrunId = :demirbasUrunId"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasSubeId", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasSubeId = :demirbasSubeId"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasTeslimperId", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasTeslimperId = :demirbasTeslimperId"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasUrunAdet", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasUrunAdet = :demirbasUrunAdet"),
    @NamedQuery(name = "Demirbaslar.findByDemirbasTarih", query = "SELECT d FROM Demirbaslar d WHERE d.demirbasTarih = :demirbasTarih")})
public class Demirbaslar implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "demirbas_id")
    private Integer demirbasId;
    @Column(name = "demirbas_urun_id")
    private Integer demirbasUrunId;
    @Column(name = "demirbas_sube_id")
    private Integer demirbasSubeId;
    @Column(name = "demirbas_teslimper_id")
    private Integer demirbasTeslimperId;
    @Column(name = "demirbas_urun_adet")
    private Integer demirbasUrunAdet;
    @Column(name = "demirbas_tarih")
    @Temporal(TemporalType.TIMESTAMP)
    private Date demirbasTarih;

    public Demirbaslar() {
    }

    public Demirbaslar(Integer demirbasId) {
        this.demirbasId = demirbasId;
    }

    public Integer getDemirbasId() {
        return demirbasId;
    }

    public void setDemirbasId(Integer demirbasId) {
        this.demirbasId = demirbasId;
    }

    public Integer getDemirbasUrunId() {
        return demirbasUrunId;
    }

    public void setDemirbasUrunId(Integer demirbasUrunId) {
        this.demirbasUrunId = demirbasUrunId;
    }

    public Integer getDemirbasSubeId() {
        return demirbasSubeId;
    }

    public void setDemirbasSubeId(Integer demirbasSubeId) {
        this.demirbasSubeId = demirbasSubeId;
    }

    public Integer getDemirbasTeslimperId() {
        return demirbasTeslimperId;
    }

    public void setDemirbasTeslimperId(Integer demirbasTeslimperId) {
        this.demirbasTeslimperId = demirbasTeslimperId;
    }

    public Integer getDemirbasUrunAdet() {
        return demirbasUrunAdet;
    }

    public void setDemirbasUrunAdet(Integer demirbasUrunAdet) {
        this.demirbasUrunAdet = demirbasUrunAdet;
    }

    public Date getDemirbasTarih() {
        return demirbasTarih;
    }

    public void setDemirbasTarih(Date demirbasTarih) {
        this.demirbasTarih = demirbasTarih;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (demirbasId != null ? demirbasId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Demirbaslar)) {
            return false;
        }
        Demirbaslar other = (Demirbaslar) object;
        if ((this.demirbasId == null && other.demirbasId != null) || (this.demirbasId != null && !this.demirbasId.equals(other.demirbasId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "envanterotomasyon.Demirbaslar[ demirbasId=" + demirbasId + " ]";
    }
    
}
