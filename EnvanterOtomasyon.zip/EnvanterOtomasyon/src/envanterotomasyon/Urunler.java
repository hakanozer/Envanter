/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package envanterotomasyon;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Java3
 */
@Entity
@Table(name = "urunler")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Urunler.findAll", query = "SELECT u FROM Urunler u"),
    @NamedQuery(name = "Urunler.findByUrunId", query = "SELECT u FROM Urunler u WHERE u.urunId = :urunId"),
    @NamedQuery(name = "Urunler.findByUrunAdi", query = "SELECT u FROM Urunler u WHERE u.urunAdi = :urunAdi"),
    @NamedQuery(name = "Urunler.findByUrunAciklama", query = "SELECT u FROM Urunler u WHERE u.urunAciklama = :urunAciklama"),
    @NamedQuery(name = "Urunler.findByUrunKatId", query = "SELECT u FROM Urunler u WHERE u.urunKatId = :urunKatId"),
    @NamedQuery(name = "Urunler.findByUrunStok", query = "SELECT u FROM Urunler u WHERE u.urunStok = :urunStok"),
    @NamedQuery(name = "Urunler.findByUrunTuru", query = "SELECT u FROM Urunler u WHERE u.urunTuru = :urunTuru"),
    @NamedQuery(name = "Urunler.findByUrunTarih", query = "SELECT u FROM Urunler u WHERE u.urunTarih = :urunTarih")})
public class Urunler implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "urun_id")
    private Integer urunId;
    @Column(name = "urun_adi")
    private String urunAdi;
    @Column(name = "urun_aciklama")
    private String urunAciklama;
    @Column(name = "urun_kat_id")
    private Integer urunKatId;
    @Column(name = "urun_stok")
    private Integer urunStok;
    @Column(name = "urun_turu")
    private String urunTuru;
    @Column(name = "urun_tarih")
    @Temporal(TemporalType.TIMESTAMP)
    private Date urunTarih;

    public Urunler() {
    }

    public Urunler(Integer urunId) {
        this.urunId = urunId;
    }

    public Integer getUrunId() {
        return urunId;
    }

    public void setUrunId(Integer urunId) {
        this.urunId = urunId;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public String getUrunAciklama() {
        return urunAciklama;
    }

    public void setUrunAciklama(String urunAciklama) {
        this.urunAciklama = urunAciklama;
    }

    public Integer getUrunKatId() {
        return urunKatId;
    }

    public void setUrunKatId(Integer urunKatId) {
        this.urunKatId = urunKatId;
    }

    public Integer getUrunStok() {
        return urunStok;
    }

    public void setUrunStok(Integer urunStok) {
        this.urunStok = urunStok;
    }

    public String getUrunTuru() {
        return urunTuru;
    }

    public void setUrunTuru(String urunTuru) {
        this.urunTuru = urunTuru;
    }

    public Date getUrunTarih() {
        return urunTarih;
    }

    public void setUrunTarih(Date urunTarih) {
        this.urunTarih = urunTarih;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (urunId != null ? urunId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Urunler)) {
            return false;
        }
        Urunler other = (Urunler) object;
        if ((this.urunId == null && other.urunId != null) || (this.urunId != null && !this.urunId.equals(other.urunId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "envanterotomasyon.Urunler[ urunId=" + urunId + " ]";
    }
    
}
