/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package envanterotomasyon;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Java3
 */
@Entity
@Table(name = "tekliflistesi")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Tekliflistesi.findAll", query = "SELECT t FROM Tekliflistesi t"),
    @NamedQuery(name = "Tekliflistesi.findByTekliflistesiId", query = "SELECT t FROM Tekliflistesi t WHERE t.tekliflistesiId = :tekliflistesiId"),
    @NamedQuery(name = "Tekliflistesi.findByTekliflistesiAdi", query = "SELECT t FROM Tekliflistesi t WHERE t.tekliflistesiAdi = :tekliflistesiAdi"),
    @NamedQuery(name = "Tekliflistesi.findByTekliflistesiTarih", query = "SELECT t FROM Tekliflistesi t WHERE t.tekliflistesiTarih = :tekliflistesiTarih"),
    @NamedQuery(name = "Tekliflistesi.findByTekliflistesiDurum", query = "SELECT t FROM Tekliflistesi t WHERE t.tekliflistesiDurum = :tekliflistesiDurum")})
public class Tekliflistesi implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "tekliflistesi_id")
    private Integer tekliflistesiId;
    @Column(name = "tekliflistesi_adi")
    private String tekliflistesiAdi;
    @Lob
    @Column(name = "tekliflistesi_aciklama")
    private String tekliflistesiAciklama;
    @Column(name = "tekliflistesi_tarih")
    @Temporal(TemporalType.TIMESTAMP)
    private Date tekliflistesiTarih;
    @Column(name = "tekliflistesi_durum")
    private Boolean tekliflistesiDurum;

    public Tekliflistesi() {
    }

    public Tekliflistesi(Integer tekliflistesiId) {
        this.tekliflistesiId = tekliflistesiId;
    }

    public Integer getTekliflistesiId() {
        return tekliflistesiId;
    }

    public void setTekliflistesiId(Integer tekliflistesiId) {
        this.tekliflistesiId = tekliflistesiId;
    }

    public String getTekliflistesiAdi() {
        return tekliflistesiAdi;
    }

    public void setTekliflistesiAdi(String tekliflistesiAdi) {
        this.tekliflistesiAdi = tekliflistesiAdi;
    }

    public String getTekliflistesiAciklama() {
        return tekliflistesiAciklama;
    }

    public void setTekliflistesiAciklama(String tekliflistesiAciklama) {
        this.tekliflistesiAciklama = tekliflistesiAciklama;
    }

    public Date getTekliflistesiTarih() {
        return tekliflistesiTarih;
    }

    public void setTekliflistesiTarih(Date tekliflistesiTarih) {
        this.tekliflistesiTarih = tekliflistesiTarih;
    }

    public Boolean getTekliflistesiDurum() {
        return tekliflistesiDurum;
    }

    public void setTekliflistesiDurum(Boolean tekliflistesiDurum) {
        this.tekliflistesiDurum = tekliflistesiDurum;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tekliflistesiId != null ? tekliflistesiId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Tekliflistesi)) {
            return false;
        }
        Tekliflistesi other = (Tekliflistesi) object;
        if ((this.tekliflistesiId == null && other.tekliflistesiId != null) || (this.tekliflistesiId != null && !this.tekliflistesiId.equals(other.tekliflistesiId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "envanterotomasyon.Tekliflistesi[ tekliflistesiId=" + tekliflistesiId + " ]";
    }
    
}
