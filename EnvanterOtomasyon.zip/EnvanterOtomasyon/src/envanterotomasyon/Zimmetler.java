/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package envanterotomasyon;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Java3
 */
@Entity
@Table(name = "zimmetler")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Zimmetler.findAll", query = "SELECT z FROM Zimmetler z"),
    @NamedQuery(name = "Zimmetler.findByZimId", query = "SELECT z FROM Zimmetler z WHERE z.zimId = :zimId"),
    @NamedQuery(name = "Zimmetler.findByZimUrunId", query = "SELECT z FROM Zimmetler z WHERE z.zimUrunId = :zimUrunId"),
    @NamedQuery(name = "Zimmetler.findByZimSubeId", query = "SELECT z FROM Zimmetler z WHERE z.zimSubeId = :zimSubeId"),
    @NamedQuery(name = "Zimmetler.findByZimPersonelId", query = "SELECT z FROM Zimmetler z WHERE z.zimPersonelId = :zimPersonelId"),
    @NamedQuery(name = "Zimmetler.findByZimUrunAdet", query = "SELECT z FROM Zimmetler z WHERE z.zimUrunAdet = :zimUrunAdet"),
    @NamedQuery(name = "Zimmetler.findByZimTarih", query = "SELECT z FROM Zimmetler z WHERE z.zimTarih = :zimTarih")})
public class Zimmetler implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "zim_id")
    private Integer zimId;
    @Column(name = "zim_urun_id")
    private Integer zimUrunId;
    @Column(name = "zim_sube_id")
    private Integer zimSubeId;
    @Column(name = "zim_personel_id")
    private Integer zimPersonelId;
    @Column(name = "zim_urun_adet")
    private Integer zimUrunAdet;
    @Column(name = "zim_tarih")
    @Temporal(TemporalType.TIMESTAMP)
    private Date zimTarih;

    public Zimmetler() {
    }

    public Zimmetler(Integer zimId) {
        this.zimId = zimId;
    }

    public Integer getZimId() {
        return zimId;
    }

    public void setZimId(Integer zimId) {
        this.zimId = zimId;
    }

    public Integer getZimUrunId() {
        return zimUrunId;
    }

    public void setZimUrunId(Integer zimUrunId) {
        this.zimUrunId = zimUrunId;
    }

    public Integer getZimSubeId() {
        return zimSubeId;
    }

    public void setZimSubeId(Integer zimSubeId) {
        this.zimSubeId = zimSubeId;
    }

    public Integer getZimPersonelId() {
        return zimPersonelId;
    }

    public void setZimPersonelId(Integer zimPersonelId) {
        this.zimPersonelId = zimPersonelId;
    }

    public Integer getZimUrunAdet() {
        return zimUrunAdet;
    }

    public void setZimUrunAdet(Integer zimUrunAdet) {
        this.zimUrunAdet = zimUrunAdet;
    }

    public Date getZimTarih() {
        return zimTarih;
    }

    public void setZimTarih(Date zimTarih) {
        this.zimTarih = zimTarih;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (zimId != null ? zimId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Zimmetler)) {
            return false;
        }
        Zimmetler other = (Zimmetler) object;
        if ((this.zimId == null && other.zimId != null) || (this.zimId != null && !this.zimId.equals(other.zimId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "envanterotomasyon.Zimmetler[ zimId=" + zimId + " ]";
    }
    
}
